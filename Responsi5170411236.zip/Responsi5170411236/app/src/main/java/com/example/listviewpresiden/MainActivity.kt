package com.example.listviewpresiden

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ListView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var listview =  findViewById<ListView>(R.id.listView)
        var list = mutableListOf<Model>()

        list.add(Model("Ir soekarno", "Presiden ke-1 Indonesia.", R.drawable.sooekarno))
        list.add(Model("Soeharto", "Presiden ke-2 Indonesia.", R.drawable.soeharto))
        list.add(Model("B.J Habibie", "Presiden ke-3 Indonesia.", R.drawable.habibie))
        list.add(Model("Abdurrahman Wahid", "Presiden ke-4 Indonesia.", R.drawable.gusdur))
        list.add(Model("Megawati Soekarnoputri", "Presiden ke-5 Indonesia", R.drawable.megawati))
        list.add(Model("Susilo Bambang Yudhoyono", "Presiden ke-6 Indonesia", R.drawable.sby))
        list.add(Model("Joko Widodo", "Presiden ke-7 Indonesia", R.drawable.jokowii))

        listview.adapter = MyAdapter(this, R.layout.row, list)

        listview.setOnItemClickListener { parent:AdapterView<*>, view:View, position:Int, id:Long ->
            if (position == 0 ){
                Toast.makeText(this@MainActivity, "Soekarno .  Adalah Presiden Pertama Republik Indonesia , Beliau Lahir di Surabaya pada tanggal 6 juni 1901, Dan meninggal dunia di jakarta pada tanggal 21 juni 1970. Beliau Menjabat pada Periode 1945-1967. Beliau adalah Proklamator Kemerdekaan Indonesia", Toast.LENGTH_LONG).show()
            }
            if (position == 1 ){
                Toast.makeText(this@MainActivity, "Soeharto . Adalah Presiden Kedua Republ Indonesia ,Beliau lahir di Kemusuk,Yogyakarta pada tanggal 8 Juni 1921 . Beliau Menjabat dari tahun 1967 sampai 1998, Menggantikan Soekarno", Toast.LENGTH_LONG).show()
            }
            if (position == 2 ){
                Toast.makeText(this@MainActivity, "Prof. Dr.-Ing. H. Bacharuddin Jusuf Habibie. Adalah Presiden KeTiga , lahir di Parepare, Sulawesi Selatan, 25 Juni 1936. Ia menggantikan Soeharto yang mengundurkan diri dari jabatan presiden pada tanggal 21 Mei 1998. ", Toast.LENGTH_LONG).show()
            }
            if (position == 3 ){
                Toast.makeText(this@MainActivity, "Dr.(H.C.) K. H. Abdurrahman Wahid / Gus Dur . Adalah Presiden ke Empat Beliau lahir di Jombang, Jawa Timur, 7 September 1940 – Beliau adalah tokoh Muslim Indonesia dan pemimpin politik yang menjadi Presiden Indonesia yang keempat dari tahun 1999 hingga 2001.", Toast.LENGTH_LONG).show()
            }
            if (position == 4 ){
                Toast.makeText(this@MainActivity, "Dr.(H.C.) Hj. Dyah Permata megawati Setyawati Soekarnoputri / megawati Soekarnoputri Beliau Presiden keLima ,lahir di Yogyakarta, 23 Januari 1947) Beliau menjabat sejak 23 Juli 2001 - 20 Oktober 2004.", Toast.LENGTH_LONG).show()
            }
            if (position == 5 ){
                Toast.makeText(this@MainActivity, "Jenderal TNI (Purn.) Prof. Dr. H. Susilo Bambang Yudhoyono . Beliau Presiden ke Enam , lahir di Tremas, Arjosari, Pacitan, Jawa Timur, Indonesia, 9 September 1949, Beliau menjabat sejak 20 Oktober 2004 hingga 20 Oktober 2014.", Toast.LENGTH_LONG).show()
            }
            if (position == 6 ){
                Toast.makeText(this@MainActivity, "Ir. H. Joko Widodo atau yang lebih akrab disapa Jokowi , Beliau Presiden ke Tujuh . lahir di Surakarta, Jawa Tengah, 21 Juni 1961 ,Beliau menjabat sejak 20 Oktober 2014 Sampai Sekarang", Toast.LENGTH_LONG).show()
            }
        }
    }
}