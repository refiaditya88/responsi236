package com.example.respons236

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import com.example.listviewpresiden.R
import com.example.listviewpresiden.akunsaya
import com.example.responsi184.LoginActivity
import kotlinx.android.synthetic.main.activity_register.*

class RegisterActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)
        val username = findViewById<EditText>(R.id.txt_username)
        val password = findViewById<EditText>(R.id.txt_password)

        btn_registrasi.setOnClickListener() {
            val username = username.text.toString()
            val password = password.text.toString()

            intent = Intent(this@RegisterActivity, akunsaya::class.java)
            intent.putExtra("Username", username)
            intent.putExtra("Password", password)
            startActivity(intent)

        }
        btn_masuk.setOnClickListener(){
            intent = Intent(this@RegisterActivity,LoginActivity::class.java)
            startActivity(intent)

        }

    }
}


